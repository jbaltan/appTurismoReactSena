#import <React/RCTBridgeModule.h>

@interface Notificaciones : NSObject <RCTBridgeModule>

@end
