import { NativeModules } from 'react-native';

const { Notificaciones } = NativeModules;

export default Notificaciones;
